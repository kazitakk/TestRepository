package wPackage;
public class Hiworld {
	public static void main(String[] args) {
		String arg [] = {"aa", "bb"};
	    String data [] = {""};        //暗号化後データ格納
	    char no = 13;         //ずらす文字数
	        //i番目の引数の番目の文字についてnestloopする
	    for(int i=0; i < arg.length; i++)
	    {
	          for(int j=0; j < arg[i].length(); j++)
	          {
	    	   if(
	    			Integer.valueOf(arg[i].charAt(j)) >= 97
	    			//97はaに対応する数字を手入力
	    			&&
	    			Integer.valueOf(arg[i].charAt(j)) < 110 )
	    	    {
	    	     data1 = data1 + String.valueOf((char)(arg[i].charAt(i) + no));
	             //暗号化(noで指定文字数プラスする)
	    	     }
	    	else if (
	    			Integer.valueOf(arg[i].charAt(j)) >= 65 &&
	    					//65はAに対応する数字を手入力
	    			Integer.valueOf(arg[i].charAt(j)) < 78)
	    	     {
	              data1 = data1 + String.valueOf((char)(arg[i].charAt(i) + no));
	              
	    	     }
	    	else if(
	    			Integer.valueOf(arg[i].charAt(j)) >= 110 &&
	    			Integer.valueOf(arg[i].charAt(j)) < 123 )
	    	       {
	                data1 = data1 + String.valueOf((char)(arg[i].charAt(j) - no));
	                //暗号化(noで指定文字数マイナスする)
	    	        }
	    	else if (
	    			Integer.valueOf(arg[i].charAt(j)) >= 78 &&
	    			Integer.valueOf(arg[i].charAt(j)) < 91)
	    	        { 
	                 data1 = data1 + String.valueOf((char)(arg[i].charAt(j) - no));
	                 
	    	        }
	    	else
	    	    {
	    		System.out.print(arg[i].charAt(j));
	    		}
	    	   System.out.println(data[i]);
	    	}
	    }     
	}
}